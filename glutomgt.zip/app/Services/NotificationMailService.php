<?php

namespace App\Services;

use App\Models\AdminOrder;
use App\Models\BuyerOrder;
use App\Models\AdminOrderTracker;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class NotificationMailService
{
    /**
     * Send a unified, beautifully formatted high-contrast Gluto International email.
     */
    protected static function sendMailable(string $recipientEmail, string $subject, string $title, string $message, ?string $ctaUrl = null, ?string $ctaText = null, array $metaSpecs = [])
    {
        Mail::send('emails.gluto-notification', [
            'title'       => $title,
            'bodyContent' => $message,
            'ctaUrl'      => $ctaUrl,
            'ctaText'     => $ctaText,
            'metaSpecs'   => $metaSpecs
        ], function ($mail) use ($recipientEmail, $subject) {
            $mail->to($recipientEmail)->subject("Gluto International | {$subject}");
        });
    }

    /**
     * Helper: Dispatch a notification copy directly to all back-office operational administrators.
     */
    protected static function emailAllActiveAdmins(string $subject, string $title, string $message, ?string $ctaUrl = null, ?string $ctaText = null, array $metaSpecs = [])
    {
        $admins = User::whereIn('usertype', ['superadmin', 'operationsadmin'])->pluck('email');

        foreach ($admins as $adminEmail) {
            self::sendMailable($adminEmail, $subject, $title, $message, $ctaUrl, $ctaText, $metaSpecs);
        }
    }

    // =========================================================================
    // BRANCH A: ADMIN SYSTEM NOTIFICATION TRIGGERS (INBOUND ALERTS TO ADMIN)
    // =========================================================================

    public static function notifyAdminOfBuyerQuote(array $quoteData, string $buyerEmail)
    {
        self::emailAllActiveAdmins(
            "New Buyer Sourcing Request Started",
            "A buyer has initiated a contract negotiation",
            "A fresh wholesale sourcing quote request has been uploaded to the dashboard lines layer. Please inspect specifications parameters and configure target unit rates pricing sheets overrides.",
            url('/admin/recent-orders'),
            "Open Operations Dashboard",
            ['Buyer Contact' => $buyerEmail, 'Commodity Scope' => $quoteData['product_names'] ?? 'Bulk Goods']
        );
    }

    /**
     * DYNAMIC FIX: Accepts the dynamic subject string context selection and reply content typed by the Buyer.
     */

    //  Buggy
    public static function notifyAdminOfBuyerConversation(BuyerOrder $order, string $customSubject, string $messageContent)
    {
        self::emailAllActiveAdmins(
            "Buyer Thread Update: {$customSubject}",
            "Message received on Order Reference #{$order->order_ref_number}",
            "A buyer profile session has appended an update note to their active negotiation thread:\n\n\"{$messageContent}\"",
            url("/admin/buyer-quotes/{$order->id}/tracker"),
            "View Tracker Thread",
            ['PO Number' => $order->order_ref_number, 'Topic Context' => $customSubject, 'Total Value' => "{$order->quotation_currency} " . number_format($order->grand_total_price, 2)]
        );
    }

    public static function notifyAdminOfInvoiceUpload(AdminOrder $order, string $supplierName)
    {
        self::emailAllActiveAdmins(
            "Supplier Invoice Dispatched",
            "Proforma Billing Statement Uploaded",
            "The vendor enterprise [{$supplierName}] has uploaded an itemized commercial proforma invoice directly against the order sheet tracking lines index. Review it to clear financial wire remittances.",
            url("/admin/suppliers/{$order->id}/tracker"),
            "Inspect Billing Invoice",
            ['Fulfilling Supplier' => $supplierName, 'PO Voucher Reference' => $order->purchase_order_number]
        );
    }

    /**
     * DYNAMIC FIX: Accepts the dynamic subject string context selection and reply content typed by the Supplier.
     */
    public static function notifyAdminOfSupplierConversation(AdminOrder $order, string $customSubject, string $messageContent)
    {
        self::emailAllActiveAdmins(
            "Supplier Thread Update: {$customSubject}",
            "Vendor Message Update Detected",
            "A wholesale manufacturing partner [{$order->supplier->company_name}] has submitted an operational response to the discussion tracker workspace:\n\n\"{$messageContent}\"",
            url("/admin/suppliers/{$order->id}/tracker"),
            "Open Admin Tracker Desk",
            ['PO Reference' => $order->purchase_order_number, 'Topic Scope' => $customSubject]
        );
    }

    // =========================================================================
    // BRANCH B: BUYER SYSTEM NOTIFICATION TRIGGERS (OUTBOUND ALERTS TO BUYER)
    // =========================================================================

    public static function notifyBuyerOfQuoteReceipt(string $buyerEmail, array $quoteDetails)
    {
        self::sendMailable(
            $buyerEmail,
            "Sourcing Request Received Successfully",
            "Sourcing Registry Acknowledgment",
            "Your cross-border bulk sourcing quote request has been securely registered on our Gluto International database indices. Back-office logistics operations staff are auditing container freight bounds to configure your pricing sheets.",
            url('/buyer/dashboard'),
            "Go to Buyer Console",
            ['Commodity Matrix' => $quoteDetails['product_names'] ?? 'Bulk Sourcing Lines']
        );
    }

    /**
     * DYNAMIC FIX: Relays the exact administrative auditing response content and subject context down to the Buyer.
     */
    public static function notifyBuyerOfQuoteTrackerUpdate(string $buyerEmail, BuyerOrder $order, string $adminSubject, string $adminMessageContent)
    {
        self::sendMailable(
            $buyerEmail,
            "Ecosystem Workspace Update: {$adminSubject}",
            "You have a response from us regarding your quote with {$order->order_ref_number}",
            "An admin manager has responded to your recently submitted quote[{$adminSubject}]:\n\n\"{$adminMessageContent}\"",
            url('/buyer/orders/' . $order->id . '/negotiation-tracker'),
            "Open Tracker Thread",
            ['Order Reference' => $order->order_ref_number, 'Subject' => $adminSubject, 'Order Progress' => $order->order_progress]
        );
    }

    public static function notifyBuyerOfReceiptUploadConfirmation(string $buyerEmail, string $orderRef)
    {
        self::sendMailable(
            $buyerEmail,
            "Wire Remittance Slip Received",
            "Payment Document Vault Logged",
            "Your uploaded bank remitted wire transfer receipt slip has been securely saved to our escrow verification ledger indexes. The Gluto International accounting clearing team is auditing the settlement payload loop.",
            url('/buyer/dashboard'),
            "Check Settlement History",
            ['Order Reference Hash' => $orderRef]
        );
    }

    // =========================================================================
    // BRANCH C: SUPPLIER SYSTEM NOTIFICATION TRIGGERS (OUTBOUND ALERTS TO SUPPLIER)
    // =========================================================================

    public static function notifySupplierOfNewAdminOrder(AdminOrder $order)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "New Inbound Purchase Order Issued",
            "Procurement Request #{$order->purchase_order_number}",
            "The Gluto International procurement team has compiled a fresh replenishment purchase order targeting your wholesale inventory items assets. Please review specifications, update milestones, and attach your proforma invoice layout statement.",
            url('/supplier/orders'),
            "Open Supplier Desk Panel",
            ['PO Number' => $order->purchase_order_number, 'Grand Contract Total' => "{$order->currency} " . number_format($order->grand_total_amount, 2)]
        );
    }

    public static function notifySupplierOfOrderStatusShift(AdminOrder $order)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "PO Progress Milestone Modified",
            "Order #{$order->purchase_order_number} Progress Shift",
            "The Gluto International back-office administrative desk has officially moved your incoming procurement contract tracking line progress state to: [{$order->order_status}].",
            url('/supplier/orders'),
            "Review Contract Progress",
            ['PO Voucher Number' => $order->purchase_order_number, 'Global Order Status' => $order->order_status, 'Freight Shipment Status' => $order->shipment_status]
        );
    }

    /**
     * DYNAMIC FIX: Relays the exact administrative auditing response content and subject context down to the Supplier.
     */
    public static function notifySupplierOfAdminMessage(AdminOrder $order, string $adminSubject, string $adminMessageContent)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "Admin Feedback Alert: {$adminSubject}",
            "Correction Target Request inside Thread",
            "A Gluto International administrator has posted an inquiry note or verification feedback request targeting topic context [{$adminSubject}]:\n\n\"{$adminMessageContent}\"",
            url('/supplier/orders'),
            "Open Supplier Tracker Desk",
            ['PO Reference' => $order->purchase_order_number, 'Audit Subject Context' => $adminSubject]
        );
    }

    public static function notifySupplierOfInvoiceConfirmation(AdminOrder $order)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "Commercial Proforma Invoice Processed",
            "Billing Statement Sync Successful",
            "Your corporate commercial proforma invoice document has been successfully processed and cached under the Gluto International administrative dashboard pipeline ledger logs tracking indexes.",
            url('/supplier/orders'),
            "Review Inbound Orders Workspace",
            ['PO Reference Tag' => $order->purchase_order_number, 'Fulfillment Status' => 'Invoice Attached']
        );
    }
}
