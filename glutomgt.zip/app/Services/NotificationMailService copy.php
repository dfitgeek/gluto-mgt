<?php

namespace App\Services;

use App\Models\AdminOrder;
use App\Models\AdminOrderTracker;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class NotificationMailService
{
    /**
     * Send a unified, beautifully formatted high-contrast Gluto International email.
     */
    protected static function sendMailable(string $recipientEmail, string $subject, string $title, string $message, ?string $ctaUrl = null, ?string $ctaText = null, array $metaSpecs = [])
    {
        Mail::send('emails.gluto-notification', [
            'title' => $title,
            'bodyContent' => $message, // FIXED: Changed parameter key name to avoid collision with Laravel's native system Message object
            'ctaUrl' => $ctaUrl,
            'ctaText' => $ctaText,
            'metaSpecs' => $metaSpecs
        ], function ($mail) use ($recipientEmail, $subject) {
            $mail->to($recipientEmail)->subject("Gluto International | {$subject}");
        });
    }

    /**
     * Helper: Dispatch a notification copy directly to all back-office operational administrators.
     */
    protected static function emailAllActiveAdmins(string $subject, string $title, string $message, ?string $ctaUrl = null, ?string $ctaText = null, array $metaSpecs = [])
    {
        // Query target privileged rows using the explicit usertype permissions column index
        $admins = User::whereIn('usertype', ['superadmin', 'operationsadmin'])->pluck('email');

        foreach ($admins as $adminEmail) {
            self::sendMailable($adminEmail, $subject, $title, $message, $ctaUrl, $ctaText, $metaSpecs);
        }
    }

    // =========================================================================
    // BRANCH A: ADMIN SYSTEM NOTIFICATION TRIGGERS
    // =========================================================================

    public static function notifyAdminOfBuyerQuote(array $quoteData, string $buyerEmail)
    {
        self::emailAllActiveAdmins(
            "New Buyer Sourcing Request Started",
            "A buyer has initiated a contract negotiation",
            "A fresh wholesale sourcing quote request has been uploaded to the dashboard lines layer. Please inspect specifications parameters and configure target unit rates pricing sheets overrides.",
            url('/admin/recent-orders'),
            "Open Operations Dashboard",
            ['Buyer Contact' => $buyerEmail, 'Commodity Scope' => $quoteData['product_names'] ?? 'Bulk Goods']
        );
    }

    public static function notifyAdminOfBuyerConversation(AdminOrder $order, string $messageSnippet)
    {
        self::emailAllActiveAdmins(
            "New Buyer Thread Response",
            "Message received on PO Reference #{$order->purchase_order_number}",
            "An enterprise buyer profile session has appended a new note to their active negotiation tracking timeline ledger: \"{$messageSnippet}\"",
            url("/admin/suppliers/{$order->id}/tracker"),
            "View Tracker Thread",
            ['PO Number' => $order->purchase_order_number, 'Total Value' => "{$order->currency} " . number_format($order->grand_total_amount, 2)]
        );
    }

    public static function notifyAdminOfInvoiceUpload(AdminOrder $order, string $supplierName)
    {
        self::emailAllActiveAdmins(
            "Supplier Invoice Dispatched",
            "Proforma Billing Statement Uploaded",
            "The vendor enterprise [{$supplierName}] has uploaded an itemized commercial proforma invoice directly against the order sheet tracking lines index. Review it to clear financial wire remittances.",
            url("/admin/suppliers/{$order->id}/tracker"),
            "Inspect Billing Invoice",
            ['Fulfilling Supplier' => $supplierName, 'PO Voucher Reference' => $order->purchase_order_number]
        );
    }

    public static function notifySupplierOfNewAdminOrder(AdminOrder $order)
    {
        // Access vendor destination account using the target table column definition index
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "New Inbound Purchase Order Issued",
            "Procurement Request #{$order->purchase_order_number}",
            "The Gluto International procurement team has compiled a fresh replenishment purchase order targeting your wholesale inventory items assets. Please review specifications, update milestones, and attach your proforma invoice layout statement.",
            url('/supplier/orders'),
            "Open Supplier Desk Panel",
            ['PO Number' => $order->purchase_order_number, 'Grand Contract Total' => "{$order->currency} " . number_format($order->grand_total_amount, 2)]
        );
    }

    public static function notifyAdminOfSupplierConversation(AdminOrder $order, string $snippetText)
    {
        self::emailAllActiveAdmins(
            "Supplier Tracker Response Appended",
            "Vendor Message Update Detected",
            "A wholesale manufacturing partner has posted an operational clarification request or update note back inside your discussion terminal tracking stream matrix: \"{$snippetText}\"",
            url("/admin/suppliers/{$order->id}/tracker"),
            "Open Admin Tracker Desk",
            ['PO Reference Number' => $order->purchase_order_number, 'Supplier Account' => $order->supplier->company_name]
        );
    }

    // =========================================================================
    // BRANCH B: BUYER SYSTEM NOTIFICATION TRIGGERS
    // =========================================================================

    public static function notifyBuyerOfQuoteReceipt(string $buyerEmail, array $quoteDetails)
    {
        self::sendMailable(
            $buyerEmail,
            "Sourcing Request Received Successfully",
            "Sourcing Registry Acknowledgment",
            "Your cross-border bulk sourcing quote request has been securely registered on our Gluto International database indices. Back-office logistics operations staff are auditing container freight bounds to configure your pricing sheets.",
            url('/buyer/dashboard'),
            "Go to Buyer Console",
            ['Commodity Matrix' => $quoteDetails['product_names'] ?? 'Bulk Sourcing Lines']
        );
    }

    public static function notifyBuyerOfQuoteTrackerUpdate(string $buyerEmail, AdminOrder $order, string $updateSubject)
    {
        self::sendMailable(
            $buyerEmail,
            "Operational Quote Tracker Progress Update",
            "Action Requested on Contract PO #{$order->purchase_order_number}",
            "A Gluto International operations admin manager has appended an auditing review milestone note or invalidation flag under topic [{$updateSubject}]. Open your tracking panel to clear errors or download shared spec documents sheets.",
            url('/buyer/dashboard'),
            "Open Tracker Dashboard Thread",
            ['PO Reference' => $order->purchase_order_number, 'Current Milestone State' => $order->order_status]
        );
    }

    public static function notifyBuyerOfReceiptUploadConfirmation(string $buyerEmail, string $orderRef)
    {
        self::sendMailable(
            $buyerEmail,
            "Wire Remittance Slip Received",
            "Payment Document Vault Logged",
            "Your uploaded bank remitted wire transfer receipt slip has been securely saved to our escrow verification ledger indexes. The Gluto International accounting clearing team is auditing the settlement payload loop.",
            url('/buyer/dashboard'),
            "Check Settlement History",
            ['Order Reference Hash' => $orderRef]
        );
    }

    // =========================================================================
    // BRANCH C: SUPPLIER SYSTEM NOTIFICATION TRIGGERS
    // =========================================================================

    public static function notifySupplierOfOrderStatusShift(AdminOrder $order)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "PO Progress Milestone Modified",
            "Order #{$order->purchase_order_number} Progress Shift",
            "The Gluto International back-office administrative desk has officially moved your incoming procurement contract tracking line progress state to: [{$order->order_status}].",
            url('/supplier/orders'),
            "Review Contract Progress",
            ['PO Voucher Number' => $order->purchase_order_number, 'Global Order Status' => $order->order_status, 'Freight Shipment Status' => $order->shipment_status]
        );
    }

    public static function notifySupplierOfAdminMessage(AdminOrder $order, string $subjectTopic, string $contentSnippet)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "Admin Feedback Alert Received",
            "Correction Target Request inside Thread",
            "A Gluto International administrator has posted an informational note or invalidation correction ticket targeting topic [{$subjectTopic}]: \"{$contentSnippet}\"",
            url('/supplier/orders'),
            "Open Supplier Tracker Desk",
            ['PO Reference' => $order->purchase_order_number, 'Audit Subject Context' => $subjectTopic]
        );
    }

    public static function notifySupplierOfInvoiceConfirmation(AdminOrder $order)
    {
        $supplierEmail = $order->supplier->rep_email;

        self::sendMailable(
            $supplierEmail,
            "Commercial Proforma Invoice Processed",
            "Billing Statement Sync Successful",
            "Your corporate commercial proforma invoice document has been successfully processed and cached under the Gluto International administrative dashboard pipeline ledger logs tracking indexes.",
            url('/supplier/orders'),
            "Review Inbound Orders Workspace",
            ['PO Reference Tag' => $order->purchase_order_number, 'Fulfillment Status' => 'Invoice Attached']
        );
    }
}
